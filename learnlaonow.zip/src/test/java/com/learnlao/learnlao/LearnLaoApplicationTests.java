package com.learnlao.learnlao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnLaoApplicationTests {

    @Test
    void contextLoads() {
    }

}
