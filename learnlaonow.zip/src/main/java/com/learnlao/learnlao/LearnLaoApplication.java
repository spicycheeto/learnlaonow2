package com.learnlao.learnlao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnLaoApplication {

    public static void main(String[] args) {
        SpringApplication.run(LearnLaoApplication.class, args);
    }

}
